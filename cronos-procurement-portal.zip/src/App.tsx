import React, { useMemo, useState } from 'react'
import { ClipboardList, Scale, DollarSign, FileCheck, Package, Download } from 'lucide-react'
import jsPDF from 'jspdf'

// ---------- CONFIG & UTILS ----------
const usd = (n:number)=> new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(n||0)

// Approval thresholds (demo):
// - POs <= 5k: Buyer can approve
// - 5k < POs <= 25k: Manager required
// - POs > 25k: Director required
const PO_MANAGER_THRESHOLD = 5000
const PO_DIRECTOR_THRESHOLD = 25000
// Quotes > 10k require Finance approval (demo)
const QUOTE_FINANCE_THRESHOLD = 10000

const roleRank: Record<string, number> = { Buyer: 1, Manager: 2, Director: 3, Finance: 3 }

function requiredApproverForPO(total:number): 'Buyer'|'Manager'|'Director' {
  if (total <= PO_MANAGER_THRESHOLD) return 'Buyer'
  if (total <= PO_DIRECTOR_THRESHOLD) return 'Manager'
  return 'Director'
}

// ---------- TYPES ----------
type Item = { id:string; itemNo:string; partNo:string; mfr:string; desc:string; qty:number }
type Vendor = { id:string; name:string; code:string }
type Bid = { itemId:string; vendorId:string; unit:number; lead:number; ship:number }
type Award = { itemId:string; vendorId:string; qty:number; unit:number; ship:number }
type QuoteLine = { itemId:string; qty:number; unit:number; ext:number }

type POLine = { itemId:string; desc:string; qty:number; unit:number }
type PO = { id:string; number:string; vendorId:string; status:'Draft'|'Pending Approval'|'Approved'|'Sent'|'Closed'; lines:POLine[]; shipping:number; tax:number; approverNeeded: 'Buyer'|'Manager'|'Director' }

type Receipt = { poNumber:string; itemId:string; qty:number; when:string }

// ---------- SAMPLE DATA ----------
const sampleVendors: Vendor[] = [
  { id:'v1', name:'Noble', code:'NOB' },
  { id:'v2', name:'Darley', code:'DAR' },
  { id:'v3', name:'ACCI', code:'ACC' },
]

const sampleItems: Item[] = [
  { id:'i1', itemNo:'1001', partNo:'01-674-3119', mfr:'Ultralife', desc:'Power Supply 300W (AN/PRC-162)', qty:20 },
  { id:'i2', itemNo:'1002', partNo:'ABC-123', mfr:'Cisco', desc:'Switch 24-port', qty:5 },
]

const sampleBids: Bid[] = [
  { itemId:'i1', vendorId:'v1', unit:188, lead:10, ship:45 },
  { itemId:'i1', vendorId:'v2', unit:195, lead:7, ship:30 },
  { itemId:'i1', vendorId:'v3', unit:210, lead:5, ship:25 },
  { itemId:'i2', vendorId:'v1', unit:600, lead:14, ship:0 },
  { itemId:'i2', vendorId:'v2', unit:640, lead:12, ship:0 },
]

// ---------- SUBCOMPONENTS ----------
function Section({ title, right, children }:{ title:string; right?:React.ReactNode; children:React.ReactNode }){
  return (
    <div className="card mb-4">
      <div className="flex items-center justify-between pb-3">
        <div className="text-base font-semibold">{title}</div>
        {right}
      </div>
      <div>{children}</div>
    </div>
  )
}

function ReceiveRow({ poNumber, line, item, recordReceipt }:{ poNumber:string; line:POLine; item:Item; recordReceipt:(poNumber:string,itemId:string,qty:number)=>void }){
  const [qtyStr, setQtyStr] = useState('0')
  return (
    <div className="grid grid-cols-1 md:grid-cols-12 gap-2 items-end">
      <div className="md:col-span-4"><div className="text-sm font-medium">{item.itemNo} — {item.desc}</div></div>
      <div className="md:col-span-2 text-sm">Ordered: {line.qty}</div>
      <div className="md:col-span-2 text-sm">Unit: {usd(line.unit)}</div>
      <div className="md:col-span-2">
        <input className="input w-full" type="number" value={qtyStr} onChange={e=>setQtyStr(e.target.value)} />
      </div>
      <div className="md:col-span-2">
        <button className="btn" onClick={()=>{ const n = Number(qtyStr||'0'); if(n>0) { recordReceipt(poNumber, line.itemId, n); setQtyStr('0') }}}>Receive</button>
      </div>
    </div>
  )
}

// ---------- APP ----------
export default function App(){
  const [activeTab, setActiveTab] = useState<'project'|'rfq'|'quote'|'pos'|'receiving'>('project')
  const [markupPct, setMarkupPct] = useState(18)
  const [awards, setAwards] = useState<Award[]>([])
  const [quoteStatus, setQuoteStatus] = useState<'Draft'|'Awaiting Approval'|'Approved'|'Accepted'>('Draft')
  const [pos, setPOs] = useState<PO[]>([])
  const [receipts, setReceipts] = useState<Receipt[]>([])
  const [userRole, setUserRole] = useState<'Buyer'|'Manager'|'Director'|'Finance'>('Buyer')

  const projectId = '25-01' // YY-SEQ format per Cronos standard
  const vendors = sampleVendors
  const items = sampleItems
  const bids = sampleBids

  const vendorById = (id:string)=> vendors.find(v=>v.id===id)!
  const itemById = (id:string)=> items.find(i=>i.id===id)!

  // Build quote from awards
  const quoteLines: QuoteLine[] = useMemo(()=> awards.map(a=>({ itemId:a.itemId, qty:a.qty, unit:a.unit*(1+markupPct/100), ext:a.qty*a.unit*(1+markupPct/100) })), [awards, markupPct])
  const quoteSubtotal = quoteLines.reduce((s,l)=>s+l.ext,0)
  const quoteShip = Math.max(awards.reduce((s,a)=>s+a.ship,0) * (1 + markupPct/100), 0)
  const quoteTax = quoteSubtotal * 0.06
  const quoteTotal = quoteSubtotal + quoteShip + quoteTax

  function awardItem(itemId:string, vendorId:string){
    const itm = itemById(itemId)
    const bid = bids.find(b=>b.itemId===itemId && b.vendorId===vendorId)
    if(!bid) return
    setAwards(prev=> [...prev.filter(a=>a.itemId!==itemId), { itemId, vendorId, qty: itm.qty, unit: bid.unit, ship: bid.ship }])
  }

  function approveQuote(){
    if (quoteTotal > QUOTE_FINANCE_THRESHOLD && userRole !== 'Finance' && userRole !== 'Director') {
      alert(`Quote requires Finance/Director approval because total (${usd(quoteTotal)}) exceeds ${usd(QUOTE_FINANCE_THRESHOLD)}.`)
      return
    }
    setQuoteStatus('Approved')
  }

  function acceptQuoteAndGeneratePOs(){
    const byVendor: Record<string, Award[]> = {}
    awards.forEach(a=>{ (byVendor[a.vendorId] ||= []).push(a) })

    // derive current counts by vendor code
    const counts: Record<string, number> = {}
    pos.forEach(p => {
      const code = vendorById(p.vendorId).code
      counts[code] = Math.max(counts[code]||0, parseInt(p.number.split('-').pop()||'0', 10))
    })

    const generated: PO[] = Object.entries(byVendor).map(([vendorId, list])=>{
      const vCode = vendorById(vendorId).code
      counts[vCode] = (counts[vCode]||0) + 1
      const seq = String(counts[vCode]).padStart(4,'0')
      const number = `${projectId}-${vCode}-${seq}` // e.g., 25-01-ACC-0001
      const lines: POLine[] = list.map(a=>({ itemId:a.itemId, desc:itemById(a.itemId).desc, qty:a.qty, unit:a.unit }))
      const shipping = list.reduce((s,a)=>s+a.ship,0)
      const subtotal = lines.reduce((s,l)=>s+l.unit*l.qty,0)
      const total = subtotal + shipping
      const approverNeeded = requiredApproverForPO(total)
      return { id:number, number, vendorId, status:'Pending Approval', lines, shipping, tax:0, approverNeeded }
    })

    setPOs(prev=>[...prev, ...generated])
    setQuoteStatus('Accepted')
    setActiveTab('pos')
  }

  function updatePOStatus(number:string, status:PO['status'], total:number, needed:'Buyer'|'Manager'|'Director'){
    if (status === 'Approved') {
      if (roleRank[userRole] < roleRank[needed]) {
        alert(`This PO requires ${needed} approval (Total ${usd(total)}). Your role is ${userRole}.`)
        return
      }
    }
    setPOs(prev=> prev.map(p=> p.number===number ? { ...p, status } : p))
  }

  function recordReceipt(poNumber:string, itemId:string, qty:number){
    if(!qty) return
    const when = new Date().toISOString().split('T')[0]
    setReceipts(prev=> [...prev, { poNumber, itemId, qty, when }])
  }

  // ---------- PDF EXPORTS ----------
  function exportQuotePDF(){
    const doc = new jsPDF()
    const title = `Quote Q-${new Date().getFullYear().toString().slice(2)}-01-v1`
    doc.text('Cronos LLC', 14, 16)
    doc.text(title, 14, 24)
    doc.text(`Status: ${quoteStatus}`, 14, 32)

    let y = 42
    doc.text('Lines:', 14, y); y += 6
    quoteLines.forEach((l, idx)=>{
      const i = itemById(l.itemId)
      doc.text(`${idx+1}. ${i.itemNo} ${i.desc}  Qty ${l.qty}  Unit ${usd(l.unit)}  Ext ${usd(l.ext)}`, 14, y)
      y += 6
    })
    y += 4
    doc.text(`Subtotal: ${usd(quoteSubtotal)}`, 14, y); y += 6
    doc.text(`Shipping: ${usd(quoteShip)}`, 14, y); y += 6
    doc.text(`Tax: ${usd(quoteTax)}`, 14, y); y += 6
    doc.text(`Total: ${usd(quoteTotal)}`, 14, y)

    doc.save(`${title}.pdf`)
  }

  function exportPoPDF(po: PO){
    const doc = new jsPDF()
    const v = vendorById(po.vendorId)
    const subtotal = po.lines.reduce((s,l)=>s+l.unit*l.qty,0)
    const total = subtotal + po.shipping + po.tax

    doc.text('Cronos LLC — Purchase Order', 14, 16)
    doc.text(`PO: ${po.number}`, 14, 24)
    doc.text(`Vendor: ${v.name} (${v.code})`, 14, 32)
    doc.text(`Status: ${po.status}`, 14, 40)

    let y = 50
    po.lines.forEach((l, idx)=>{
      const i = itemById(l.itemId)
      doc.text(`${idx+1}. ${i.itemNo} ${l.desc}  Qty ${l.qty}  Unit ${usd(l.unit)}  Ext ${usd(l.unit*l.qty)}`, 14, y)
      y += 6
    })
    y += 4
    doc.text(`Subtotal: ${usd(subtotal)}`, 14, y); y += 6
    doc.text(`Shipping: ${usd(po.shipping)}`, 14, y); y += 6
    doc.text(`Tax: ${usd(po.tax)}`, 14, y); y += 6
    doc.text(`Total: ${usd(total)}`, 14, y)

    doc.save(`PO-${po.number}.pdf`)
  }

  // ---------- RENDER ----------
  return (
    <div className="p-6 space-y-4 max-w-7xl mx-auto">
      <header className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="text-2xl font-bold">Cronos Procurement Portal</div>
          <span className="badge">Project 25-01</span>
        </div>
        <div className="flex items-center gap-2 text-sm">
          <label className="label">Role</label>
          <select className="input" value={userRole} onChange={e=>setUserRole(e.target.value as any)}>
            <option value="Buyer">Buyer</option>
            <option value="Manager">Manager</option>
            <option value="Director">Director</option>
            <option value="Finance">Finance</option>
          </select>
          <div className="text-neutral-500">MVP • Approvals + PDF export</div>
        </div>
      </header>

      {/* KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <div className="card flex flex-col gap-1"><div className="text-xs text-neutral-500">RFQs</div><div className="text-lg font-semibold">2 Open</div></div>
        <div className="card flex flex-col gap-1"><div className="text-xs text-neutral-500">Awards</div><div className="text-lg font-semibold">{awards.length}/{items.length} Items</div></div>
        <div className="card flex flex-col gap-1"><div className="text-xs text-neutral-500">Quote</div><div className="text-lg font-semibold">{quoteStatus}</div></div>
        <div className="card flex flex-col gap-1"><div className="text-xs text-neutral-500">POs</div><div className="text-lg font-semibold">{pos.length} Generated</div></div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 flex-wrap">
        <button className={"btn " + (activeTab==='project'?'':'secondary')} onClick={()=>setActiveTab('project')}>Project / BOM</button>
        <button className={"btn " + (activeTab==='rfq'?'':'secondary')} onClick={()=>setActiveTab('rfq')}>RFQ Compare</button>
        <button className={"btn " + (activeTab==='quote'?'':'secondary')} onClick={()=>setActiveTab('quote')}>Quote Builder</button>
        <button className={"btn " + (activeTab==='pos'?'':'secondary')} onClick={()=>setActiveTab('pos')}>PO Review</button>
        <button className={"btn " + (activeTab==='receiving'?'':'secondary')} onClick={()=>setActiveTab('receiving')}>Receiving</button>
      </div>

      {activeTab==='project' && (
        <>
          <Section title="Bill of Materials">
            <div className="overflow-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr>
                    <th className="py-2">Item #</th>
                    <th>Part #</th>
                    <th>Mfr</th>
                    <th>Description</th>
                    <th>Qty</th>
                  </tr>
                </thead>
                <tbody>
                  {items.map(itm=> (
                    <tr key={itm.id}>
                      <td className="py-2 font-medium">{itm.itemNo}</td>
                      <td>{itm.partNo}</td>
                      <td>{itm.mfr}</td>
                      <td>{itm.desc}</td>
                      <td>{itm.qty}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Section>
          <div className="card">
            <div className="flex gap-2">
              <button className="btn" onClick={()=>setActiveTab('rfq')}>Go to RFQ Compare</button>
            </div>
          </div>
        </>
      )}

      {activeTab==='rfq' && (
        <>
          {items.map(itm=> (
            <Section key={itm.id} title={`Item ${itm.itemNo}: ${itm.desc} (Qty: ${itm.qty})`}>
              <div className="overflow-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr>
                      <th className="py-2">Vendor</th>
                      <th>Unit</th>
                      <th>Lead</th>
                      <th>Ship</th>
                      <th>Total</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {bids.filter(b=>b.itemId===itm.id).map(b=>{
                      const v = vendorById(b.vendorId)
                      const total = b.unit*itm.qty + b.ship
                      const isAwarded = awards.find(a=>a.itemId===itm.id && a.vendorId===v.id)
                      return (
                        <tr key={`${itm.id}-${v.id}`}>
                          <td className="py-2 font-medium">{v.name}</td>
                          <td>{usd(b.unit)}</td>
                          <td>{b.lead}d</td>
                          <td>{usd(b.ship)}</td>
                          <td>{usd(total)}</td>
                          <td>
                            <button className={"btn " + (isAwarded ? "secondary" : "")} onClick={()=>awardItem(itm.id, v.id)}>
                              {isAwarded ? "Awarded" : "Award"}
                            </button>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            </Section>
          ))}
          <div className="card">
            <div className="flex gap-2">
              <button className="btn secondary" onClick={()=>setActiveTab('project')}>Back</button>
              <button className="btn" disabled={awards.length===0} onClick={()=>setActiveTab('quote')}>Build Quote</button>
            </div>
          </div>
        </>
      )}

      {activeTab==='quote' && (
        <>
          <Section title={`Quote Q-${new Date().getFullYear().toString().slice(2)}-01-v1`} right={
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <span className="label text-xs">Markup %</span>
                <input type="number" className="input w-20 h-8" value={markupPct} onChange={e=>setMarkupPct(parseFloat(e.target.value||'0'))}/>
              </div>
              <span className="badge">{quoteStatus}</span>
              <button className="btn secondary" onClick={exportQuotePDF}><Download className="w-4 h-4 mr-2"/>Export PDF</button>
            </div>
          }>
            {awards.length===0 ? (
              <div className="text-sm text-neutral-500">No awarded lines yet. Award items in RFQ Compare.</div>
            ):(
              <div className="overflow-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr>
                      <th className="py-2">Line</th>
                      <th>Item</th>
                      <th>Description</th>
                      <th>Qty</th>
                      <th>Unit</th>
                      <th>Ext</th>
                    </tr>
                  </thead>
                  <tbody>
                    {quoteLines.map((l,idx)=>{
                      const i = itemById(l.itemId)
                      return (
                        <tr key={l.itemId}>
                          <td className="py-2">{idx+1}</td>
                          <td>{i.itemNo}</td>
                          <td>{i.desc}</td>
                          <td>{l.qty}</td>
                          <td>{usd(l.unit)}</td>
                          <td>{usd(l.ext)}</td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
                <div className="mt-4 grid gap-1 text-sm max-w-sm ml-auto">
                  <div className="flex justify-between"><span>Subtotal</span><span>{usd(quoteSubtotal)}</span></div>
                  <div className="flex justify-between"><span>Shipping</span><span>{usd(quoteShip)}</span></div>
                  <div className="flex justify-between"><span>Tax (6%)</span><span>{usd(quoteTax)}</span></div>
                  <div className="flex justify-between font-semibold text-base"><span>Total</span><span>{usd(quoteTotal)}</span></div>
                </div>
              </div>
            )}
          </Section>
          <div className="card">
            <div className="flex gap-2 flex-wrap">
              <button className="btn secondary" onClick={()=>setActiveTab('rfq')}>Back</button>
              <button className="btn" disabled={awards.length===0 || quoteStatus!=='Draft'} onClick={()=>setQuoteStatus('Awaiting Approval')}>Send for Approval</button>
              <button className="btn" disabled={quoteStatus!=='Awaiting Approval'} onClick={approveQuote}>Approve Quote</button>
              <button className="btn" disabled={quoteStatus!=='Approved'} onClick={acceptQuoteAndGeneratePOs}>Mark Accepted & Generate POs</button>
            </div>
          </div>
        </>
      )}

      {activeTab==='pos' && (
        <>
          {pos.length===0 ? (
            <Section title="Purchase Orders">
              <div className="text-sm text-neutral-500">No POs yet. Approve & accept a quote to generate vendor POs.</div>
            </Section>
          ) : (
            pos.map(po=>{
              const v = vendorById(po.vendorId)
              const subtotal = po.lines.reduce((s,l)=>s+l.unit*l.qty,0)
              const total = subtotal + po.shipping + po.tax
              const needed = po.approverNeeded
              const canApprove = roleRank[userRole] >= roleRank[needed]
              return (
                <Section key={po.number} title={`PO ${po.number} • Vendor: ${v.name}`} right={<span className="badge">{po.status}</span>}>
                  <div className="overflow-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr>
                          <th className="py-2">Item #</th>
                          <th>Description</th>
                          <th>Qty</th>
                          <th>Unit</th>
                          <th>Ext</th>
                        </tr>
                      </thead>
                      <tbody>
                        {po.lines.map((l,idx)=>{
                          const i = itemById(l.itemId)
                          return (
                            <tr key={`${po.number}-${idx}`}>
                              <td className="py-2">{i.itemNo}</td>
                              <td>{l.desc}</td>
                              <td>{l.qty}</td>
                              <td>{usd(l.unit)}</td>
                              <td>{usd(l.unit*l.qty)}</td>
                            </tr>
                          )
                        })}
                      </tbody>
                    </table>
                  </div>
                  <div className="mt-4 grid gap-1 text-sm max-w-sm ml-auto">
                    <div className="flex justify-between"><span>Subtotal</span><span>{usd(subtotal)}</span></div>
                    <div className="flex justify-between"><span>Shipping</span><span>{usd(po.shipping)}</span></div>
                    <div className="flex justify-between"><span>Tax</span><span>{usd(po.tax)}</span></div>
                    <div className="flex justify-between font-semibold text-base"><span>Total</span><span>{usd(total)}</span></div>
                    <div className="flex justify-between text-xs text-neutral-500"><span>Required Approver</span><span>{needed}</span></div>
                  </div>
                  <div className="mt-4 flex gap-2 flex-wrap">
                    <button className="btn secondary" onClick={()=>updatePOStatus(po.number, 'Approved', total, needed)} disabled={!canApprove}>Approve (as {userRole})</button>
                    <button className="btn" onClick={()=>updatePOStatus(po.number, 'Sent', total, needed)} disabled={po.status!=='Approved'}>Email PO</button>
                    <button className="btn outline" onClick={()=>exportPoPDF(po)}><Download className="w-4 h-4 mr-2"/>Export PDF</button>
                  </div>
                </Section>
              )
            })
          )}
          <div className="card">
            <div className="flex gap-2">
              <button className="btn secondary" onClick={()=>setActiveTab('quote')}>Back</button>
              <button className="btn" onClick={()=>setActiveTab('receiving')}><Package className="w-4 h-4 mr-2" />Go to Receiving</button>
            </div>
          </div>
        </>
      )}

      {activeTab==='receiving' && (
        <>
          {pos.length===0 ? (
            <Section title="Receiving">
              <div className="text-sm text-neutral-500">No POs available. Generate POs first.</div>
            </Section>
          ):(
            <>
              {pos.map(po=> (
                <Section key={`rcv-${po.number}`} title={`Receive against PO ${po.number}`}>
                  <div className="space-y-3">
                    {po.lines.map((l,idx)=>{
                      const i = itemById(l.itemId)
                      return <ReceiveRow key={`${po.number}-rcv-${idx}`} poNumber={po.number} line={l} item={i} recordReceipt={recordReceipt} />
                    })}
                  </div>
                </Section>
              ))}
              <Section title="Receipt Log">
                {receipts.length===0 ? (
                  <div className="text-sm text-neutral-500">No receipts yet.</div>
                ):(
                  <div className="overflow-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr>
                          <th className="py-2">Date</th>
                          <th>PO</th>
                          <th>Item #</th>
                          <th>Qty</th>
                        </tr>
                      </thead>
                      <tbody>
                        {receipts.map((r,idx)=>{
                          const i = itemById(r.itemId)
                          return (
                            <tr key={`log-${idx}`}>
                              <td className="py-2">{r.when}</td>
                              <td>{r.poNumber}</td>
                              <td>{i.itemNo}</td>
                              <td>{r.qty}</td>
                            </tr>
                          )
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </Section>
              <div className="card">
                <div className="flex gap-2">
                  <button className="btn secondary" onClick={()=>setActiveTab('pos')}>Back</button>
                </div>
              </div>
            </>
          )}
        </>
      )}

      <footer className="text-xs text-neutral-500 text-center py-2">© {new Date().getFullYear()} Cronos LLC • Prototype • PO numbering (25-01-ACC-0001) + approvals + PDF export</footer>
    </div>
  )
}