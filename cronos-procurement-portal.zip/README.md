# Cronos Procurement Portal (Prototype)

A ready-to-run React + Vite + TypeScript prototype of the Cronos procurement portal with:
- RFQ compare and awarding
- Quote builder (markup, totals) with PDF export
- PO generation with numbering `YY-SEQ-VENDORCODE-####` (e.g., `25-01-ACC-0001`)
- Approval thresholds (Buyer/Manager/Director; Finance for quotes over $10k)
- PO review with PDF export
- Receiving & receipt log

## Quick Start
```bash
npm install
npm run dev
```
Open http://localhost:3000

## Tech
- React 18 + Vite + TypeScript
- TailwindCSS (utility classes)
- jsPDF for client-side PDF export
- lucide-react icons

## Notes
- All data is in-memory; refresh clears the state.
- This is an MVP prototype; no backend or database.
- To persist projects/POs and add email sending, hook up a backend (NestJS/.NET) and replace the PDF with server-rendered branded PDFs.